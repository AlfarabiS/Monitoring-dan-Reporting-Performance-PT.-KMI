@extends('layout.navbar')
@extends('layout.guest_layout')