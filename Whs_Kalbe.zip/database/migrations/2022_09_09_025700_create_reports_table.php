<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('reports', function (Blueprint $table) {
            $table->id();
            $table->string('NIK');
            $table->string('process_id');
            $table->string('gudang_id');
            $table->datetime('reports_time');
            $table->integer('qty');
            $table->string('satuan');
            $table->time('work_time');
            $table->time('hold_time');
            $table->integer('hold_count');
            $table->float('performance');
            $table->text('keterangan')->nullable;
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('reports');
    }
};
