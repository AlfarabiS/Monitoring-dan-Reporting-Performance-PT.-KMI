


<?php $__env->startSection('content'); ?>

<div class="container ml-5">

    <form action="/administrator/proses/post" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-control w-full max-w-xs">
            <label class="label">
            <span class="label-text">Nama Proses</span>
            </label>
            <input type="text" name="process_name" placeholder="Nama Proses" value="<?php echo e($ProcessName); ?>" class="input input-bordered w-full max-w-xs">
        </div>
        <div class="form-control w-full max-w-xs">
            <label class="label">
            <span class="label-text">ID Proses</span>
            </label>
            <input type="text" name="process_id" value="<?php echo e($ProcessId); ?>" placeholder="FG-Loading" class="input input-bordered w-full max-w-xs">
        </div>
        <div class="form-control w-full max-w-xs">
            <label class="label">
            <span class="label-text">Lokasi</span>
            </label>
            <select class="select select-bordered w-full max-w-xs" name="gudang_id" id="">
                <option value="FG">Finish Good</option>
                <option value="RM">Raw Material</option>
                <option value="PM">Packaging Material</option>
            </select>
        </div>
        <div class="form-control w-full max-w-xs">
            <div class="flex">
                <div class="mr-2">
                    <label class="label">
                        <span class="label-text">Qty</span>
                    </label>
                    <input type="number" name="qty" placeholder="00" value="<?php echo e($Qty); ?>"  class="input input-bordered w-full max-w-xs "    >
                </div>
                <div class="">
                    <label class="label">
                        <span class="label-text">Satuan</span>
                        </label>
                    <select class="select select-bordered  max-w-xs" name="satuan">
                        <?php $__currentLoopData = $Satuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $satuan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($satuan->satuan); ?>"><?php echo e($satuan->satuan); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
                    </select>
                </div>
                <div class="ml-2">
                    <label class="label">
                        <span class="label-text">Waktu</span>
                        </label>
                        <input type="number" class="input input-bordered w-full max-w-xs" name="time" id="" placeholder="Menit" value="<?php echo e($Time); ?>">
                </div>
            </div>
        </div>
        <div class="form-control w-full max-w-xs mt-5">
            <button type="submit" class="w-full text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Submit</button>
        </div>
    </form>

</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.superadmin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\App\Web\Kalbe\resources\views//superadmin/crud_proses.blade.php ENDPATH**/ ?>