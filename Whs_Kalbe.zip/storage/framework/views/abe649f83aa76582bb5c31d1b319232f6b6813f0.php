


<?php $__env->startSection('content'); ?>

<div class="ml-10 w-full">

    <form action="/administrator/satuan/post" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-control w-full max-w-xs">
            <label class="label">
            <span class="label-text">Satuan</span>
            </label>
            <input type="text" name="satuan" placeholder="Name" value="<?php echo e($Satuan); ?>" class="input input-bordered w-full max-w-xs" required>
            <input type="hidden" name="id" value="<?php echo e($Id); ?>">
        </div>
        
        <div class="form-control w-full max-w-xs mt-5">
            <button type="submit" class="w-full text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Submit</button>
        </div>
    </form>

</div>

<script>
function changePassword(){
    var checkbox = document.getElementById('checkboxPassword');
    var password = document.getElementById('passwordField');
    
    if (checkbox.checked == true){
        password.style.display = "block";
      } else {
        password.style.display = "none";
      }
}



</script>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.superadmin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\App\Web\Kalbe\resources\views//superadmin/crud_satuan.blade.php ENDPATH**/ ?>