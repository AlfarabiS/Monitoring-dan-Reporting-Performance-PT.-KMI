<!-- script -->
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<script src="js/scripts.js"></script>
<!-- end script -->

</body>
</html><?php /**PATH C:\App\Web\Kalbe\resources\views/base/end.blade.php ENDPATH**/ ?>