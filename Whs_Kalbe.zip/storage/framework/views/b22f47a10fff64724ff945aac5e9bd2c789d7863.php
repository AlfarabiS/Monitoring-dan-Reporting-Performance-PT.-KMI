


<?php $__env->startSection('content'); ?>
<div class="flex mb-2">
  
  
  <span class="bg-green-400 h-10 w-10 ml-10 rounded-full  transition">
    <a href="/administrator/proses/add">
        <i class="hover:scale-150 mx-3 my-3 fa fa-plus transition"></i>    
    </a>
  </span>
  <span>
    <a href="/administrator/proses/add">
    <h1 class="mt-2 ml-2">Tambah Baru</h1>
    </a>
  </span>
</div>
    
<div class="overflow-x-scroll  h-96  hover:shadow-xl transition">
  <table class="w-full h-2 table table-zebra table-compact">
      <thead class=" text-black">
          <tr class="sticky top-0">    
              <th class="w-2 border text-center whitespace-nowrap">No</th>
              <th class="w-10 border text-center whitespace-nowrap"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('process_id','Id Process'));?></th>
              <th class="w-10 border text-center whitespace-nowrap"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('process_name','Proses'));?></th>
              <th class="w-10 border text-center whitespace-nowrap"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('gudang_id','Lokasi'));?></th>    
              <th class="border text-center	w-2 whitespace-nowrap">Action</th>        
      </thead>
      <tbody class="">    
          <?php $__currentLoopData = $Processes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $process): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   
          <tr class=" hover">
              <td class=" border  text-center whitespace-nowrap"><?php echo e($loop->iteration); ?></td>
              <td class=" border  text-center whitespace-nowrap"><?php echo e($process->process_id); ?></td>
              <td class=" border  text-center whitespace-nowrap"><?php echo e($process->process_name); ?></td>                
              <td class=" border  text-center whitespace-nowrap"><?php echo e($process->gudang_id); ?></td>                 
              <td class=" border  text-center whitespace-nowrap">
                <div class="flex">    
                  <span class="bg-green-400 h-10 w-10 px-auto mx-auto rounded-full  transition">
                    <form action="/administrator/proses/edit" method="POST">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="id_proses" value="<?php echo e($process->process_id); ?>">
                      <button type="submit">
                        <i class="hover:scale-150 mx-auto my-3 fa fa-pencil transition"></i>
                      </button>  
                    </form>
                  </span>
                  <span class="bg-red-500 h-10 w-10  px-auto mx-auto rounded-full">
                    <form action="/administrator/proses/delete" method="POST">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="id_proses" value="<?php echo e($process->process_id); ?>">
                      <button type="submit">
                        <i class="hover:scale-150 mx-auto my-3 fa fa-trash transition"></i>
                      </button>  
                    </form>                  
                  </span>
                </div>
              </td>                 
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
      </tbody>
  </table>
  
</div>



  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.superadmin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\App\Web\Kalbe\resources\views//superadmin/proses.blade.php ENDPATH**/ ?>