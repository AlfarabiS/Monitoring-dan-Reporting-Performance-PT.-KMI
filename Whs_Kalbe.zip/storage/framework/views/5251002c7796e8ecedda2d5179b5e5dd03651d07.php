



<?php $__env->startSection('content'); ?>
<div class="ml-10 mb-5 mt-2 flex grid-col-2">
    <form action="/admin/report" method="get" name="report" id="report">
        <select class="select select-bordered max-w-xs mt-2" name="name">
            <option disabled selected>Pilih Nama</option>
            <?php $__currentLoopData = $Users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option><?php echo e($user->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <input type="date" name="start_date" class="ml-0 md:ml-3 input mt-2 max-w-xs" value="2020-01-01" required>
            <h1 class="inline font-extrabold text-xl">-</h1>
        <input type="date" name="end_date" class=" input mt-2 max-w-xs" value="<?php echo e(date('Y-m-d')); ?>" required>
        
        <button type="submit" class="mt-2 ml-2 text-white bg-blue-600 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Set</button> 
    </form>
    <form action="/admin/report/export" method="get" class="">
        <input type="hidden" name="name" value="<?php echo e($name); ?>" id="">
        <input type="hidden" name="date_start" value="<?php echo e($date_start); ?>" id="">
        <input type="hidden" name="date_end" value="<?php echo e($date_end); ?>" id="">
        <button type="submit" class="mt-3 ml-2 text-white bg-green-500 hover:bg-green-600 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800 hover:scale-105 transition"> 
            Export      
        </button> 
    </form>
</div>
<div class="overflow-x-scroll h-96 rounded-lg hover:shadow-xl transition">
    <table class="w-full h-2 text-center table table-zebra table-compact ">
        <thead class=" ">
            <tr class="sticky bg-gray-800 top-0 h-8 bg-gray">    
                <th class="w-2 border text-center whitespace-nowrap">No</th>
                <th class="w-60 border  text-center whitespace-nowrap"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('name','Nama'));?></th>
                <th class="w-20 border  text-center whitespace-nowrap"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('gudang','Lokasi'));?></th>
                <th class="w-20 border  text-center whitespace-nowrap"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('proses','Proses'));?></th>
                <th class="w-20 border  text-center whitespace-nowrap"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('date','Waktu'));?></th>
                <th class="w-5 border  text-center whitespace-nowrap">Waktu Kerja</th>
                <th class="w-5 border  text-center whitespace-nowrap"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('performance','Performance'));?></th>
            </tr>
        </thead>
        <tbody class="">  
            <?php $__currentLoopData = $Report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="bg-gray ">
                <td class=" whitespace-nowrap"><?php echo e($loop->iteration); ?></td>
                <td class=" whitespace-nowrap"><?php echo e($report->name); ?></td>
                <td class=" whitespace-nowrap"><?php echo e($report->gudang_name); ?></td>
                <td class=" whitespace-nowrap"><?php echo e($report->process_name); ?></td>
                <td class=" whitespace-nowrap"><?php echo e($report->reports_time); ?></td>
                <td class=" whitespace-nowrap"><?php echo e($report->work_time); ?></td>         
                <td class=" whitespace-nowrap"><?php echo e($report->performance); ?>%</td>         
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        </tbody>
    </table>
    <?php echo e($Report->onEachSide(1)->links()); ?>


</div>  

<script>
        // document.addEventListener("DOMContentLoaded", function(event) {
        //     document.createElement('form').submit.call(document.getElementById('report'));
        //     });  
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\App\Web\Kalbe\resources\views//admin/report.blade.php ENDPATH**/ ?>