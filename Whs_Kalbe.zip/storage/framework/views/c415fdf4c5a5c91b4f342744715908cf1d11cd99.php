




<?php $__env->startSection('content'); ?>



<div class="overflow-x-scroll  h-96  hover:shadow-xl transition">
    <table class="w-full h-2 table table-zebra table-compact text-center">
        <thead class=" text-black">
            <tr class="sticky top-0">    
                <th class="w-2 border  whitespace-nowrap">No</th>
                <th class="w-10 border whitespace-nowrap"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('name','Nama'));?></th>
                <th class="w-10 border whitespace-nowrap"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('lokasi','Lokasi'));?></th>    
                <th class="table-fixed border w-5 whitespace-nowrap"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('status','Status'));?></th>        
                <th class="table-fixed border w-5 whitespace-nowrap">keterangan</th>        
        </thead>
        <tbody class="">    
            <?php $__currentLoopData = $Users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     
            <tr class=" hover">
                <td class=" border  whitespace-nowrap"><?php echo e($loop->iteration); ?></td>
                <td class=" border  whitespace-nowrap"><?php echo e($user->name); ?></td>
                <td class=" border  whitespace-nowrap"><?php echo e($user->gudang_name); ?></td>                
                <td class=" border   whitespace-nowrap">
                    <?php if($user->active == 1): ?>
                        <span class="w-3 h-3 float-right bg-green-700 shadow-2xl rounded-full"></span>
                    <?php else: ?> 
                        <span class="w-3 h-3 float-right bg-slate-400 shadow-2xl rounded-full"></span>
                    <?php endif; ?>
                    <?php echo e($user->process_name); ?>

                </td>
                <td class=" border  whitespace-nowrap"><?php echo e($user->keterangan); ?></td>                
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </tbody>
    </table>
    
</div>  

<script type="text/javascript">
    function load()
    {
    setTimeout("window.open(self.location, '_self');", 5*60000);
    }
</script>
    <body onload="load()">       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\App\Web\Kalbe\resources\views//admin/tracking1.blade.php ENDPATH**/ ?>