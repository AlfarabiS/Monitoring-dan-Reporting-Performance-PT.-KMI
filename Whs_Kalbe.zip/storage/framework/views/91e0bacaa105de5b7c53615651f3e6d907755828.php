<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($judul); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />


   </head>
   <body class="bg-slate-100 ">

      

      <div class="drawer drawer-mobile mt-10">
         <input id="my-drawer" type="checkbox" class="drawer-toggle" />
         <div class="drawer-content">
            <div class="grid grid-cols-2 ">
               <div class="mb-6 mt-5 ml-10">
                  <p class="text-3xl font-bold "><?php echo e($judul); ?></p>
               </div>   
            </div>
            <?php echo $__env->yieldContent('content'); ?>
          </div> 
         <div class="drawer-side ">
           <label for="my-drawer" class="drawer-overlay"></label>
           <ul class="menu p-4 overflow-y-auto w-60 bg-gray-800 text-base-content">
             <!-- Sidebar content here -->
             <li>
               <a href="/administrator/user" class="flex items-center p-2 text-base font-normal  rounded-lg text-white hover:bg-gray-700 dark:hover:bg-gray-700">
                  <span class="flex-1 ml-3 whitespace-nowrap">User</span>
                  <span><i class="fa fa-user font-white"></i></span>
               </a>
            </li>
            <li>
               <a href="/administrator/proses" class="flex items-center p-2 text-base font-normal  rounded-lg text-white hover:bg-gray-700 dark:hover:bg-gray-700">
                  <span class="flex-1 ml-3 whitespace-nowrap">proses</span>
                  <span><i class="fa fa-user font-white"></i></span>
               </a>
            </li>
            <li>
               <a href="/tracking/pm" class="flex items-center p-2 text-base font-normal  rounded-lg text-white hover:bg-gray-700 dark:hover:bg-gray-700">
                  <span class="flex-1 ml-3 whitespace-nowrap">Tracking PM</span>
                  <span><i class="fa fa-user font-white"></i></span>
               </a>
            </li>
            <li>
               <form action="/logout" method="POST">
                  <?php echo csrf_field(); ?>
                  <button class="w-full flex item-center p-2 text-base font-normal rounded-lg text-white hover:bg-gray-700 dark:hover:bg-gray-700">                       
                     <span class="flex-1  whitespace-nowrap">
                        Logout 
                        <i class=" fa fa-sign-out fa-2xs"></i>
                     </span>
                  </button>
               </form>
            </li>
           </ul>
         </div>
       </div>
  

      

       
  
   </body>
   </html><?php /**PATH C:\App\Web\Kalbe\resources\views//layout/superadmin_layout.blade.php ENDPATH**/ ?>