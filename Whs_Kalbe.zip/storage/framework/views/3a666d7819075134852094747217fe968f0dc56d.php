




<?php $__env->startSection('content'); ?>
<div class="overflow-x-scroll h-96 rounded-lg hover:shadow-xl transition">
    <table class="w-full h-2 table table-zebra table-compact text-center">
        <thead class="">
            <tr class="sticky top-0 h-8 ">    
                <th class="w-2 whitespace-nowrap">No</th>
                <th class="w-60 whitespace-nowrap"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('name','Nama'));?></th>
                <th class="w-20 whitespace-nowrap">NIK</th>    
            <?php $__currentLoopData = $Processes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $process): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th class="table-fixed	w-20   whitespace-nowrap"><?php echo e($process->process_name); ?></th>        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </thead>

        <tbody class="">    
            <?php $__currentLoopData = $Users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     
            <tr class="hover">
                <td class="border whitespace-nowrap"><?php echo e($loop->iteration); ?></td>
                <td class="bordercenter whitespace-nowrap"><?php echo e($user->name); ?></td>
                <td class="border whitespace-nowrap"><?php echo e($user->NIK); ?></td>                
                <?php $__currentLoopData = $Processes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $process): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($user->process_id === $process->process_id): ?>
                    <td class="border object-none object-center whitespace-nowrap">
                        <div class="tooltip" data-tip="<?php echo e($user->keterangan); ?>">
                            <i class=" fa fa-user"  ></i>
                        </div>
                    </td>  
                <?php else: ?>
                    <td class="border whitespace-nowrap"></td>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </tbody>
    </table>
</div>  
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\App\Web\Kalbe\resources\views//admin/tracking.blade.php ENDPATH**/ ?>